package com.portfolio.mad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MadApplication {

	public static void main(String[] args) {
		SpringApplication.run(MadApplication.class, args);
	}

}
