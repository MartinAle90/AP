package com.example.mad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MadApplicationTests {

	@Test
	void contextLoads() {
	}

}
